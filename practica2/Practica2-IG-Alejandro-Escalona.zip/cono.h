//
// Created by aescx on 25/10/20.
//
//
//#ifndef PRÁCTICA_2_CONO_H
//#define PRÁCTICA_2_CONO_H
#include "objetos_B2.h"

class _cono: public _rotacion{

    public:
        _cono();
        vector<_vertex3f> perfil;
    };

//
//#endif //PRÁCTICA_2_CONO_H
