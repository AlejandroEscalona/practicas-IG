//
// Created by aescx on 25/10/20.
//

//#ifndef PRACTICA_2_CILINDRO_H
//#define PRACTICA_2_CILINDRO_H
#include "objetos_B2.h"

class _cilindro: public _rotacion{
public:
    _cilindro();
    vector<_vertex3f> perfil;

};


//#endif //PRÁCTICA_2__CILINDRO_H
