//
// Created by aescx on 30/10/20.
//

#ifndef PRACTICA2_PLY_REVOLUCION_H
#define PRACTICA2_PLY_REVOLUCION_H
#include "objetos_B2.h"


class _ply_revolucion: public _rotacion{
        public:
        _ply_revolucion();
        vector<_vertex3f> perfil;

};

#endif //PRACTICA2_PLY_REVOLUCION_H
