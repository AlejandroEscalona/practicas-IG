//
// Created by aescx on 25/10/20.
//

//#ifndef PRÁCTICA_2_CILINDROX_H
//#define PRÁCTICA_2_CILINDROX_H
#include "objetos_B2.h"


class _cilindrox: public _rotacion{

public:
    _cilindrox();
    vector<_vertex3f> perfil;

};


//#endif //PRÁCTICA_2_CILINDROX_H
