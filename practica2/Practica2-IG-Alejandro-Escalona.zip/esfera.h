//
// Created by aescx on 25/10/20.
//

//#ifndef PRÁCTICA_2_ESFERA_H
//#define PRÁCTICA_2_ESFERA_H
#include "objetos_B2.h"



class _esfera: public _rotacion{

public:
    _esfera();

    vector<_vertex3f> perfil;
};


//
//#endif //PRÁCTICA_2_ESFERA_H
